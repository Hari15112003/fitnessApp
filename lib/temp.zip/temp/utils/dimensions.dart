

const webScreenSize = 600;
